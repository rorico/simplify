(function() {var c = require('./c')
module.exports = () => {
	return c()
}})()